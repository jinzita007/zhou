$(function(){
    $('#owl-demo').owlCarousel({
        items: 5,
        lazyLoad: true,
        /*itemsDesktop: true,
        itemsDesktopSmall: true,*/
        itemsTablet:true,
        itemsTabletSmall:false,
        itemsMobile:true,

    });
});

